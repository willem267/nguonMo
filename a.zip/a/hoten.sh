echo "Nhap ho: "
read ho
echo "Nhap ten: "
read ten
echo "Ho va ten cua ban la $ho $ten"
