sudo apt update
sudo apt install php
