sudo apt update
sudo apt install mysql-server
