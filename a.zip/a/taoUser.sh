#!/bin/bash

# Hàm kiểm tra tính hợp lệ của tên người dùng
is_valid_username() {
    # Kiểm tra tên người dùng phải bắt đầu bằng 'TH' và có ít nhất 4 ký tự
    if [[ ! "$1" =~ ^TH.{2,}$ ]]; then
        echo "Tên người dùng không hợp lệ. Tên người dùng phải bắt đầu bằng 'TH' và có ít nhất 4 ký tự."
        return 1
    fi
    return 0
}

# Nhập tên người dùng
read -p "Nhập tên người dùng cần tạo: " username

# Kiểm tra tính hợp lệ của tên người dùng
if ! is_valid_username "$username"; then
    exit 1
fi

# Kiểm tra xem người dùng đã tồn tại chưa
if id "$username" &>/dev/null; then
    echo "Người dùng '$username' đã tồn tại."
    exit 1
fi

# Tạo người dùng mới
sudo useradd -m "$username"

# Cài đặt mật khẩu cho người dùng
sudo passwd "$username"

echo "Người dùng '$username' đã được tạo thành công!"
