echo "Nhap so a: "
read a
echo "Nhap so b: "
read b

if [ "$a" -eq 0 ]; then
	if [ "$b" -eq 0 ]; then
		echo "PTVSN"
	else
		echo "PTVN"
	fi
else
	x=$(echo "scale=2; -$b / $a" | bc)
	echo "Nghiem cua pt la: $x"
fi
