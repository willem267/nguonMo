sudo apt update
sudo apt install apache2
